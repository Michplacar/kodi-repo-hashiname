Univision IPTV addon for Kodi
=============================

Plugin to watch Univision Anywhere IPTV on kodi. You will need a login credential that can be obtained [here](http://my.univision.mn/index.php/register).

### Disclaimer
The addon provider is not responsible for any issues caused by using this addon. In addition, it is a third-party addon that is not affiliated with Univision Anywhere in any way.

### Installation
Download the zip (on the right of github page) and use the kodi menu to install it: System -> Add-ons -> Install from zip file -> Find the downloaded file.
